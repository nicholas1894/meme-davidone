import React, { useEffect, useState } from "react";
import { Button } from "tailwindcss";
import { Card, CardContent } from "tailwindcss";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "tailwindcss";
import { motion } from "framer-motion";

export default function Home() {
  const [copied, setCopied] = useState(false);
  const [timeLeft, setTimeLeft] = useState(345600); // 4 giorni in secondi

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft((prev) => (prev > 0 ? prev - 1 : 0));
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const formatTime = (seconds) => {
    const d = Math.floor(seconds / 86400);
    const h = Math.floor((seconds % 86400) / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    const s = seconds % 60;
    return `${d}d ${h}h ${m}m ${s}s`;
  };

  const contract = "0x1234567890ABCDEF...";

  return (
    <div
      className="min-h-screen bg-fixed bg-cover bg-center p-4 font-bold text-center"
      style={{ backgroundImage: "url('/A_2D_digital_illustration_serves_as_the_homepage_o.png')" }}
    >
      <div className="backdrop-blur-sm bg-white/60 p-6 md:p-10 rounded-2xl">
        <h1 className="text-5xl md:text-7xl text-red-600 mb-4 drop-shadow">DAVIDONE</h1>
        <p className="text-xl md:text-2xl mb-6 text-gray-800">La coin più leggendaria della blockchain</p>

        <Tabs defaultValue="home" className="max-w-4xl mx-auto">
          <TabsList className="grid grid-cols-3 bg-white p-2 rounded-full shadow-lg">
            <TabsTrigger value="home">Home</TabsTrigger>
            <TabsTrigger value="mission">Obiettivi</TabsTrigger>
            <TabsTrigger value="ceo">Il CEO</TabsTrigger>
          </TabsList>

          <TabsContent value="home">
            <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.4 }}>
              <Card className="bg-white/90 shadow-2xl rounded-2xl mt-6">
                <CardContent className="p-6">
                  <img
                    src="https://cdn.pixabay.com/photo/2023/11/10/20/52/ai-generated-8379936_1280.jpg"
                    alt="Davidone 3D"
                    className="mx-auto mb-4 rounded-xl shadow-xl"
                  />
                  <p className="text-lg mb-2">Contract:</p>
                  <p className="text-sm bg-gray-100 p-2 rounded-md mb-4 break-all shadow-inner">{contract}</p>
                  <Button
                    className="bg-gradient-to-br from-yellow-300 to-pink-400 text-black font-bold shadow-md border-b-4 border-yellow-600 transform hover:scale-105 transition-transform"
                    onClick={() => {
                      navigator.clipboard.writeText(contract);
                      setCopied(true);
                      setTimeout(() => setCopied(false), 1500);
                    }}
                  >
                    {copied ? "Copiato!" : "Copia Contract"}
                  </Button>
                  <div className="mt-6">
                    <Button variant="link" className="text-blue-700 underline" disabled>
                      Segui DAVIDONE su X (presto disponibile)
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </TabsContent>

          <TabsContent value="mission">
            <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.4 }}>
              <Card className="bg-white/90 shadow-2xl rounded-2xl mt-6">
                <CardContent className="p-6 space-y-6">
                  <h2 className="text-3xl text-green-600">La missione di DAVIDONE</h2>
                  <div className="grid md:grid-cols-3 gap-6">
                    <div className="flex flex-col items-center">
                      <img src="https://cdn.pixabay.com/photo/2023/07/01/15/34/rocket-8100293_1280.png" alt="Rocket" className="w-24 h-24 mb-2" />
                      <p className="text-lg">1.000 holders</p>
                    </div>
                    <div className="flex flex-col items-center">
                      <img src="https://cdn.pixabay.com/photo/2012/04/18/13/21/chart-36878_1280.png" alt="Chart" className="w-24 h-24 mb-2" />
                      <p className="text-lg">Listino su CoinGecko</p>
                    </div>
                    <div className="flex flex-col items-center">
                      <img src="https://cdn.pixabay.com/photo/2018/06/29/04/59/t-shirt-3503822_1280.png" alt="Merch" className="w-24 h-24 mb-2" />
                      <p className="text-lg">Merchandising ufficiale</p>
                    </div>
                  </div>
                  <div className="text-center mt-4">
                    <p className="text-xl mb-2">Burn tra:</p>
                    <p className="text-2xl font-mono text-red-500 animate-pulse">{formatTime(timeLeft)}</p>
                    {timeLeft === 0 && (
                      <p className="text-xl text-red-700 font-bold mt-4">🔥 Una parte dei DAVIDONE è stata bruciata!</p>
                    )}
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </TabsContent>

          <TabsContent value="ceo">
            <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.4 }}>
              <Card className="bg-white/90 shadow-2xl rounded-2xl mt-6">
                <CardContent className="p-6">
                  <h2 className="text-3xl text-purple-600 mb-4">Conosci il nostro CEO</h2>
                  <img
                    src="https://cdn.pixabay.com/photo/2024/02/01/13/27/ai-generated-8548307_1280.jpg"
                    alt="CEO Davidone"
                    className="mx-auto mb-4 rounded-full shadow-xl w-64 h-64 object-cover"
                  />
                  <p className="text-lg text-gray-800">
                    DAVIDONE è nato tra i meme e forgiato nella blockchain. Visionario, leggendario e forse... un po’ matto.
                    Ma è proprio questo che serve per conquistare il mondo delle crypto!
                  </p>
                </CardContent>
              </Card>
            </motion.div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}